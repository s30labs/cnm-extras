use warnings;
use strict;
use feature 'say';

use Script::Singleton warn => 1;

sleep 10;
