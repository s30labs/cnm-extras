package Net::OpenSSH::SSH;

1;

__END__

=head1 NAME

Net::OpenSSH::SSH - Perl SSH client package implemented on top of OpenSSH

=head1 DESCRIPTION

Use the real thing: L<Net::OpenSSH>.

This namespace is used so that the module gets indexed under the
C<SSH> tag on popular CPAN search engines such as
L<http://metacpan.org> and L<http://search.cpan.org>.

=cut
