package Crypt::SSLeay::CTX;
require Crypt::SSLeay;
use strict;
1;
