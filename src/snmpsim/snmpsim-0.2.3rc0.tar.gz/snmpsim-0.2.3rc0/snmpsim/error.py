class SnmpsimError(Exception): pass
class NoDataNotification(SnmpsimError): pass
class MoreDataNotification(SnmpsimError): pass
