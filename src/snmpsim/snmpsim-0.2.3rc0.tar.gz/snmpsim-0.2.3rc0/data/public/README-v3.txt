This directory serves as a special case only when Simulator is NOT running
in --v2c-arch mode.

This is a ContextName specific directory.

The .snmprec files in this directory would be used by Simulator whenever
ContextName in request AND Manager's source address matches the .snmprec
filename.
