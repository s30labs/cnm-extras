This directory serves as a special case only when Simulator is running
in --v2c-arch mode.

This is a community name specific directory.

The .snmprec files in this directory would be used by Simulator whenever
community name in request AND Manager's source address matches the .snmprec
filename.
