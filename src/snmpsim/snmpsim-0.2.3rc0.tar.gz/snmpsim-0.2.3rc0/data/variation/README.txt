This directory is an example repository of .snmprec files that use
various value variation modules for the purpose of building SNMP
responses.
