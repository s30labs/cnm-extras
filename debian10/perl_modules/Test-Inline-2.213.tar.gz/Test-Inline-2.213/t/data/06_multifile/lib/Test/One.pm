package Test::One;

=pod

=begin testing foo 1

ok( 1, 'Good test' );

=end testing

=cut

use strict;

print "Hello World!\n";

1;
