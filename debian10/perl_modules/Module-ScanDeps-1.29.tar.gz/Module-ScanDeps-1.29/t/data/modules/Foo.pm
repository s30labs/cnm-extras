package Foo;

use Net::FTP;

1;
