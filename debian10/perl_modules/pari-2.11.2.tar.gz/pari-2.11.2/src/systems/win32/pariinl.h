/*   This file contains declarations/definitions of functions that
 *   _can_ be inlined.
 */
#include "../src/kernel/ix86/level0.h"
#include "../src/kernel/none/level1.h"

