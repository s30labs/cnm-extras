#include <time.h>
int main(){ struct tm *x = NULL; strftime("",1," ",x); return 0; }
