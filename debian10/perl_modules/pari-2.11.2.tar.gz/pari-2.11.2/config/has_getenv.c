#include <stdlib.h>
int main(){ (void)getenv(""); return 0; }
