#ifndef ASMINLINE
