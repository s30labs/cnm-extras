package LWP::DebugFile;

our $VERSION = '6.51';

# legacy stub

1;
