package LWP::DebugFile;

our $VERSION = '6.50';

# legacy stub

1;
