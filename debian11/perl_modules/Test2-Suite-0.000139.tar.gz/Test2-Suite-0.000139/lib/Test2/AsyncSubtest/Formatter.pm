package Test2::AsyncSubtest::Formatter;
use strict;
use warnings;

our $VERSION = '0.000139';

die "Should not load this anymore";

1;
