package Test::Two;

use strict;

print "Hello World!\n";

1;
