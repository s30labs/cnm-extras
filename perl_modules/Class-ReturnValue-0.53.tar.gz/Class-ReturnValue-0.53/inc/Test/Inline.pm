#line 1 "inc/Test/Inline.pm - /opt/perl-5.8.0/lib/site_perl/Test/Inline.pm"
package Test::Inline;

$VERSION = '0.15';


#line 175

1;
