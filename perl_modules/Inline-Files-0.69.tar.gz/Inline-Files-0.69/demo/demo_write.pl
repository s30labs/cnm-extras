use Inline::Files;

print VIRTUAL "This should work";

__VIRTUAL__
This should not be inviolate
