
package t::Auth;

use strict;
use warnings;

use base 'Net::IMAP::Server::DefaultAuth';

1;
